rootProject.name = "com.ironbird.ktor-mongo"
